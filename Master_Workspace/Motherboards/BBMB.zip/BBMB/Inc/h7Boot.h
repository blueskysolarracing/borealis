void arm_boot();
void disarm_boot();
